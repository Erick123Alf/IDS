/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cajero;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author PC
 */
public class Conexion {
    
    public Connection getConnetion()
    {
        Connection con = null;
        String base = "bdcajero";
        String url = "jdbc:mysql://localhost:3306/"+base;
        String user = "root";
        String pass = "";
        
        try
        {
          Class.forName("com.mysql.jdbc.Driver");
          con = (Connection) DriverManager.getConnection(url, user, pass);
        }
        catch(Exception e)
        {
            System.err.print(e);
        }
        
        return con;
    }
}
