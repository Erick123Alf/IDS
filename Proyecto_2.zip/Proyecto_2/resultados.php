<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados de Datos</title>
    <script src="https://kit.fontawesome.com/a71707a89a.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="dive2">
        <h1>Resultados</h1>
        <center>
            <img src="img/homer.jpeg" alt="homer">
        </center>
        
        <h2>¡Bien Hecho!</h2>
        <center>
        <?php
        $name = $_POST['Name'];
        $age = $_POST['Age'];
        $city = $_POST['City'];
        $fecha_nacimiento = $_POST['Fecha_Nacimiento'];
        $pasatiempo = $_POST['Pasatiempo'];

        echo '<p><b>Nombre: </b>'.$name. '</p>';
        echo '<p><b>Edad: </b>'.$age. '</p>';
        echo '<p><b>Ciudad: </b>'.$city. '</p>';
        echo '<p><b>Fecha de Nacimiento: </b>'.$fecha_nacimiento. '</p>';
        echo '<p><b>Pasatiempo: </b>'.$pasatiempo. '</p>';
        ?>   
        </center>
           <div id = "popUpOverlay"></div>
        <div id = "popUpBox">
        <div id = "box">
            <i class = "fas fa-question-circle fa-5x"></i>
            <h1>¿Volver a ingresar datos?</h1>
        <div id = "closeModal"></div>
            </div>
        </div>
        <center>
        <button onclick = "Alert.render('You look very pretty today.')" class = "btn">¡Volver a Ingresar!</button>
        <script src = "js/app.js"></script>
        </center>
    </div>
</body>
</html>